import { useEffect, useRef, useState } from "react";
import { Game, type HudState, type Held, type Trigger } from "./game/Game";
import soldierUrl from "./assets/soldier.glb?url";

const initial: HudState = {
  loading: true,
  progress: 0,
  ammo: 30,
  reserve: 120,
  health: 100,
  status: "Idle",
  speed: 0,
  reloading: false,
  reloadProgress: 0,
  locked: false,
  dead: false,
  crouch: false,
  ads: false,
  sprint: false,
  showcase: false,
  fps: 60,
  spread: 0.01,
  hitMarker: 0,
  timeScale: 1,
};

const KEYS: [string, string][] = [
  ["W A S D", "Move"],
  ["Mouse", "Aim / look"],
  ["LMB  /  F", "Fire (hold)"],
  ["RMB  /  Z", "Aim down sights"],
  ["Shift", "Sprint"],
  ["C  /  Ctrl", "Crouch"],
  ["Space", "Jump"],
  ["R", "Reload"],
  ["Q / E", "Lean"],
  ["H", "Take hit"],
  ["K / L", "Die (back / front)"],
  ["T", "Respawn"],
  ["Tab", "Showcase orbit"],
];

export default function App() {
  const host = useRef<HTMLDivElement>(null);
  const game = useRef<Game | null>(null);
  const [hud, setHud] = useState<HudState>(initial);
  const [showKeys, setShowKeys] = useState(true);

  useEffect(() => {
    if (!host.current) return;
    const g = new Game(host.current, setHud);
    game.current = g;
    g.init().catch((e) => console.error(e));
    return () => {
      g.dispose();
      game.current = null;
    };
  }, []);

  const trig = (t: Trigger) => () => game.current?.trigger(t);
  const hold = (k: Held, v: boolean) => game.current?.setHeld(k, v);

  const download = () => {
    const a = document.createElement("a");
    a.href = soldierUrl;
    a.download = "soldier_rigged.glb";
    a.click();
  };

  const healthPct = Math.max(0, hud.health);
  const spreadPx = 6 + hud.spread * 1800;

  return (
    <div className="relative h-screen w-screen select-none overflow-hidden bg-black font-sans text-zinc-100">
      <div ref={host} className="absolute inset-0" />

      {/* vignette */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_55%,rgba(0,0,0,0.55)_100%)]" />
      {hud.health < 100 && !hud.dead && (
        <div className="pointer-events-none absolute inset-0" style={{ boxShadow: `inset 0 0 ${120 + (100 - hud.health)}px rgba(160,0,0,${(100 - hud.health) / 160})` }} />
      )}

      {/* crosshair */}
      {!hud.loading && !hud.dead && !hud.showcase && (
        <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="relative" style={{ width: spreadPx * 2, height: spreadPx * 2 }}>
            {[0, 90, 180, 270].map((r) => (
              <div key={r} className="absolute left-1/2 top-1/2" style={{ transform: `rotate(${r}deg) translateY(-${spreadPx}px)` }}>
                <div className="-ml-px h-2.5 w-0.5 bg-white/90 shadow-[0_0_2px_rgba(0,0,0,0.9)]" />
              </div>
            ))}
            <div className="absolute left-1/2 top-1/2 h-[3px] w-[3px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-white shadow-[0_0_3px_rgba(0,0,0,1)]" />
            {hud.hitMarker > 0 && (
              <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-xl font-black text-red-500 drop-shadow">✕</div>
            )}
          </div>
        </div>
      )}

      {/* title + status */}
      <div className="pointer-events-none absolute left-5 top-5 space-y-3">
        <div>
          <div className="text-[10px] font-semibold uppercase tracking-[0.35em] text-amber-400/90">Character Animation Lab</div>
          <h1 className="text-2xl font-black uppercase tracking-wide text-white drop-shadow-lg">Vanguard · Operator</h1>
        </div>
        <div className="flex items-center gap-2">
          <span className={`rounded border px-2.5 py-1 text-xs font-bold uppercase tracking-widest backdrop-blur ${hud.dead ? "border-red-500/60 bg-red-950/60 text-red-300" : hud.reloading ? "border-amber-400/60 bg-amber-950/50 text-amber-300" : "border-emerald-400/40 bg-black/50 text-emerald-300"}`}>
            {hud.status}
          </span>
          <span className="rounded border border-white/10 bg-black/50 px-2 py-1 font-mono text-xs text-zinc-300 backdrop-blur">{hud.speed.toFixed(1)} m/s</span>
          <span className="rounded border border-white/10 bg-black/50 px-2 py-1 font-mono text-xs text-zinc-400 backdrop-blur">{Math.round(hud.fps)} fps</span>
        </div>
      </div>

      {/* right panel */}
      {!hud.loading && (
        <div className="absolute right-5 top-5 max-h-[calc(100vh-190px)] w-64 space-y-3 overflow-y-auto rounded-xl border border-white/10 bg-black/55 p-4 shadow-2xl backdrop-blur-md">
          <div className="text-[10px] font-semibold uppercase tracking-[0.3em] text-zinc-400">Animations</div>
          <div className="grid grid-cols-2 gap-2">
            <Btn label="Fire" sub="hold" onDown={() => hold("fire", true)} onUp={() => hold("fire", false)} accent />
            <Btn label="Reload" sub="R" onClick={trig("reload")} />
            <Btn label="Jump" sub="Space" onClick={trig("jump")} />
            <Btn label="Take Hit" sub="H" onClick={trig("hit")} />
            <Btn label="Crouch" sub="C" active={hud.crouch} onClick={() => game.current?.toggleHeld("crouch")} />
            <Btn label="Aim (ADS)" sub="RMB" active={hud.ads} onClick={() => game.current?.toggleHeld("ads")} />
            <Btn label="Sprint" sub="Shift" active={hud.sprint} onClick={() => game.current?.toggleHeld("sprint")} />
            <Btn label="Showcase" sub="Tab" active={hud.showcase} onClick={trig("showcase")} />
            <Btn label="Die · Back" sub="K" onClick={trig("dieBack")} danger />
            <Btn label="Die · Front" sub="L" onClick={trig("dieFront")} danger />
          </div>
          <Btn label="Respawn" sub="T" onClick={trig("respawn")} wide />

          <div className="pt-1">
            <div className="mb-1.5 flex items-center justify-between text-[10px] font-semibold uppercase tracking-[0.3em] text-zinc-400">
              <span>Time scale</span>
              <span className="font-mono normal-case tracking-normal text-amber-300">{hud.timeScale}×</span>
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {[0.1, 0.25, 0.5, 1].map((v) => (
                <button
                  key={v}
                  onClick={() => {
                    game.current?.setTimeScale(v);
                    setHud((h) => ({ ...h, timeScale: v }));
                  }}
                  className={`rounded-md border py-1 text-xs font-semibold transition ${hud.timeScale === v ? "border-amber-400 bg-amber-400/20 text-amber-200" : "border-white/10 bg-white/5 text-zinc-300 hover:bg-white/10"}`}
                >
                  {v}×
                </button>
              ))}
            </div>
          </div>

          <button onClick={download} className="flex w-full items-center justify-center gap-2 rounded-md border border-sky-400/40 bg-sky-500/15 py-2 text-xs font-bold uppercase tracking-widest text-sky-200 transition hover:bg-sky-500/30">
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 3v12m0 0l-4-4m4 4l4-4M4 21h16" />
            </svg>
            Download rigged GLB
          </button>
        </div>
      )}

      {/* controls */}
      {!hud.loading && (
        <div className="absolute bottom-5 left-5">
          <button onClick={() => setShowKeys((s) => !s)} className="mb-2 rounded border border-white/10 bg-black/50 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.25em] text-zinc-300 backdrop-blur hover:bg-black/70">
            {showKeys ? "Hide controls" : "Controls"}
          </button>
          {showKeys && (
            <div className="grid grid-cols-[auto_auto] gap-x-4 gap-y-1 rounded-xl border border-white/10 bg-black/55 p-3 text-xs backdrop-blur-md">
              {KEYS.map(([k, v]) => (
                <div key={k} className="contents">
                  <span className="font-mono font-semibold text-amber-300">{k}</span>
                  <span className="text-zinc-300">{v}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ammo + health */}
      {!hud.loading && (
        <div className="pointer-events-none absolute bottom-5 right-5 w-64 space-y-2 text-right">
          {hud.reloading && (
            <div className="ml-auto h-1.5 w-48 overflow-hidden rounded bg-white/15">
              <div className="h-full bg-amber-400" style={{ width: `${hud.reloadProgress * 100}%` }} />
            </div>
          )}
          <div className="font-mono leading-none">
            <span className={`text-6xl font-black tabular-nums drop-shadow-lg ${hud.ammo <= 8 ? "text-red-400" : "text-white"}`}>{String(hud.ammo).padStart(2, "0")}</span>
            <span className="ml-1 text-2xl font-bold text-zinc-400">/ {hud.reserve}</span>
          </div>
          <div className="flex items-center justify-end gap-2">
            <span className="text-[10px] font-semibold uppercase tracking-[0.3em] text-zinc-400">HP</span>
            <div className="h-2.5 w-44 overflow-hidden rounded-sm border border-white/15 bg-black/60">
              <div className={`h-full transition-all duration-200 ${healthPct > 50 ? "bg-emerald-400" : healthPct > 25 ? "bg-amber-400" : "bg-red-500"}`} style={{ width: `${healthPct}%` }} />
            </div>
            <span className="w-8 font-mono text-sm text-zinc-200">{Math.round(healthPct)}</span>
          </div>
        </div>
      )}

      {/* capture hint */}
      {!hud.loading && !hud.locked && !hud.dead && (
        <div className="pointer-events-none absolute bottom-6 left-1/2 -translate-x-1/2 rounded-full border border-white/15 bg-black/60 px-4 py-2 text-xs text-zinc-200 backdrop-blur">
          <b className="text-amber-300">Click the scene</b> to capture the mouse · <b className="text-amber-300">Esc</b> to release · drag to look if capture is blocked
        </div>
      )}

      {/* death */}
      {hud.dead && (
        <div className="absolute inset-x-0 top-1/3 flex flex-col items-center gap-4">
          <div className="text-6xl font-black uppercase tracking-[0.3em] text-red-500 drop-shadow-[0_0_20px_rgba(255,0,0,0.5)]">K.I.A.</div>
          <button onClick={trig("respawn")} className="rounded-md border border-white/30 bg-white/10 px-6 py-2 text-sm font-bold uppercase tracking-widest backdrop-blur transition hover:bg-white/25">
            Respawn (T)
          </button>
        </div>
      )}

      {/* loading */}
      {hud.loading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-zinc-950">
          <div className="text-xs font-semibold uppercase tracking-[0.4em] text-amber-400">Loading operator</div>
          <div className="h-1 w-64 overflow-hidden rounded bg-white/10">
            <div className="h-full animate-pulse bg-amber-400 transition-all" style={{ width: `${Math.max(8, hud.progress * 100)}%` }} />
          </div>
        </div>
      )}
    </div>
  );
}

function Btn(props: {
  label: string;
  sub?: string;
  onClick?: () => void;
  onDown?: () => void;
  onUp?: () => void;
  active?: boolean;
  danger?: boolean;
  accent?: boolean;
  wide?: boolean;
}) {
  const { label, sub, onClick, onDown, onUp, active, danger, accent, wide } = props;
  const tone = active
    ? "border-amber-400 bg-amber-400/25 text-amber-100"
    : danger
      ? "border-red-400/30 bg-red-500/10 text-red-200 hover:bg-red-500/25"
      : accent
        ? "border-orange-400/40 bg-orange-500/15 text-orange-100 hover:bg-orange-500/30"
        : "border-white/10 bg-white/5 text-zinc-200 hover:bg-white/12";
  return (
    <button
      onClick={onClick}
      onPointerDown={onDown}
      onPointerUp={onUp}
      onPointerLeave={onUp}
      onContextMenu={(e) => e.preventDefault()}
      className={`flex flex-col items-start rounded-md border px-2.5 py-1.5 text-left transition active:scale-95 ${tone} ${wide ? "w-full" : ""}`}
    >
      <span className="text-xs font-bold">{label}</span>
      {sub && <span className="font-mono text-[9px] uppercase tracking-wider opacity-60">{sub}</span>}
    </button>
  );
}
