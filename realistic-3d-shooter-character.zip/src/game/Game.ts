import * as THREE from "three";
import { SoldierRig, MAG_SIZE, type RigStatus } from "../character/SoldierRig";
import { buildWorld, type World, type SurfaceKind } from "./world";
import { CombatFX, Sfx } from "./fx";
import { Spring, clamp, damp, lerp } from "../character/math";

export interface HudState {
  loading: boolean;
  progress: number;
  ammo: number;
  reserve: number;
  health: number;
  status: RigStatus;
  speed: number;
  reloading: boolean;
  reloadProgress: number;
  locked: boolean;
  dead: boolean;
  crouch: boolean;
  ads: boolean;
  sprint: boolean;
  showcase: boolean;
  fps: number;
  spread: number;
  hitMarker: number;
  timeScale: number;
}

export type Trigger = "reload" | "jump" | "hit" | "dieBack" | "dieFront" | "respawn" | "showcase";
export type Held = "fire" | "ads" | "sprint" | "crouch";

export class Game {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.PerspectiveCamera(62, 1, 0.05, 400);
  world!: World;
  rig!: SoldierRig;
  fx = new CombatFX();
  sfx = new Sfx();

  private keys = new Set<string>();
  private uiHeld: Record<Held, boolean> = { fire: false, ads: false, sprint: false, crouch: false };
  private mouseL = false;
  private mouseR = false;
  private locked = false;
  private yaw = 0;
  private pitch = 0.05;
  private camYaw = 0;
  private camPitch = 0.05;
  private showcase = false;
  private crouchToggle = false;
  private adsBlend = 0;
  private sprintFov = 0;
  private health = 100;
  private raf = 0;
  private last = performance.now();
  private hudT = 0;
  private fpsAcc = 0;
  private fpsN = 0;
  private fps = 60;
  private camKick = new Spring(150, 14);
  private shakeX = new Spring(300, 20);
  private shakeY = new Spring(300, 20);
  private hitMarker = 0;
  private spread = 0;
  private timeScale = 1;
  private pivotY = 1.5;
  private raycaster = new THREE.Raycaster();
  private loading = true;
  private progress = 0;
  private disposed = false;
  private ro?: ResizeObserver;
  private cleanup: (() => void)[] = [];

  constructor(
    private container: HTMLElement,
    private onHud: (s: HudState) => void,
  ) {
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance", preserveDrawingBuffer: false });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.78;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.domElement.style.display = "block";
    this.renderer.domElement.tabIndex = 0;
    container.appendChild(this.renderer.domElement);
    this.camera.position.set(0.6, 1.8, -3);
    this.bind();
    this.resize();
    this.emitHud();
  }

  async init() {
    this.world = buildWorld(this.scene, this.renderer);
    this.scene.add(this.fx.group);
    this.rig = await SoldierRig.load(this.scene, (p) => {
      this.progress = p;
      this.emitHud();
    });
    if (this.disposed) return;
    this.rig.rifle.muzzle.add(this.fx.flash);
    this.rig.events = {
      onShot: (m, kick) => this.onShot(m, kick),
      onEject: (p, d) => this.fx.casing(p, d),
      onDry: () => this.sfx.dry(),
      onFootstep: (_s, i) => this.sfx.step(i),
      onReloadEvent: (k) => {
        if (k === "magout") this.sfx.magOut();
        else if (k === "magin") this.sfx.magIn();
        else if (k === "bolt") this.sfx.bolt();
        else if (k === "drop") this.sfx.magDrop();
      },
      onLand: (i) => this.sfx.land(i),
      onHit: () => this.sfx.hit(),
      onDeath: () => this.sfx.fall(),
    };
    this.rig.root.position.set(0, 0, 0);
    this.loading = false;
    (window as unknown as { __game: Game }).__game = this;
    this.last = performance.now();
    const loop = (t: number) => {
      this.raf = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (t - this.last) / 1000);
      this.last = t;
      this.frame(dt);
    };
    this.raf = requestAnimationFrame(loop);
  }

  /* ------------------------------------------------------------ */
  private bind() {
    const el = this.renderer.domElement;
    const on = <K extends keyof WindowEventMap>(t: Window | HTMLElement | Document, ev: string, fn: (e: never) => void, opt?: AddEventListenerOptions) => {
      (t as EventTarget).addEventListener(ev, fn as EventListener, opt);
      this.cleanup.push(() => (t as EventTarget).removeEventListener(ev, fn as EventListener));
      return null as unknown as K;
    };
    on(window, "keydown", (e: KeyboardEvent) => {
      this.sfx.init();
      if (["Space", "ArrowUp", "ArrowDown", "Tab"].includes(e.code)) e.preventDefault();
      if (e.repeat) return;
      this.keys.add(e.code);
      switch (e.code) {
        case "Space":
          this.trigger("jump");
          break;
        case "KeyR":
          this.trigger("reload");
          break;
        case "KeyC":
          this.crouchToggle = !this.crouchToggle;
          break;
        case "KeyH":
          this.trigger("hit");
          break;
        case "KeyK":
          this.trigger("dieBack");
          break;
        case "KeyL":
          this.trigger("dieFront");
          break;
        case "KeyT":
          this.trigger("respawn");
          break;
        case "Tab":
          this.trigger("showcase");
          break;
      }
    });
    on(window, "keyup", (e: KeyboardEvent) => this.keys.delete(e.code));
    on(window, "blur", () => this.keys.clear());
    on(el, "contextmenu", (e: Event) => e.preventDefault());
    on(el, "mousedown", (e: MouseEvent) => {
      this.sfx.init();
      if (e.button === 0) {
        this.mouseL = true;
        if (!this.locked && !this.lockFailed) this.requestLock();
      }
      if (e.button === 2) this.mouseR = true;
    });
    on(window, "mouseup", (e: MouseEvent) => {
      if (e.button === 0) this.mouseL = false;
      if (e.button === 2) this.mouseR = false;
    });
    on(window, "mousemove", (e: MouseEvent) => {
      const drag = this.mouseL || this.mouseR;
      if (!this.locked && !drag) return;
      const s = 0.0022 * (this.adsBlend > 0.5 ? 0.6 : 1);
      this.camYaw -= e.movementX * s;
      this.camPitch = clamp(this.camPitch - e.movementY * s, -1.2, 1.25);
      if (!this.showcase) {
        this.yaw = this.camYaw;
        this.pitch = this.camPitch;
      }
    });
    on(el, "wheel", (e: WheelEvent) => {
      this.zoomDist = clamp(this.zoomDist + e.deltaY * 0.002, 1.0, 6);
    });
    on(document, "pointerlockchange", () => {
      this.locked = document.pointerLockElement === el;
      this.emitHud();
    });
    on(document, "pointerlockerror", () => {
      this.lockFailed = true;
      this.emitHud();
    });
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(this.container);
  }
  private lockFailed = false;
  private zoomDist = 2.7;

  private requestLock() {
    try {
      const p = this.renderer.domElement.requestPointerLock() as unknown as Promise<void> | undefined;
      p?.catch?.(() => (this.lockFailed = true));
    } catch {
      this.lockFailed = true;
    }
  }

  private resize() {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.renderer.domElement.style.width = "100%";
    this.renderer.domElement.style.height = "100%";
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    const s = (h * this.renderer.getPixelRatio()) / (2 * Math.tan(THREE.MathUtils.degToRad(this.camera.fov) / 2));
    this.fx.setScale(s);
  }

  /* ------------------------------------------------------------ */
  setHeld(k: Held, v: boolean) {
    this.uiHeld[k] = v;
  }
  toggleHeld(k: Held) {
    if (k === "crouch") this.crouchToggle = !this.crouchToggle;
    else this.uiHeld[k] = !this.uiHeld[k];
    this.emitHud();
  }
  setTimeScale(v: number) {
    this.timeScale = v;
  }
  trigger(t: Trigger) {
    if (!this.rig) return;
    this.sfx.init();
    switch (t) {
      case "reload":
        this.rig.reload();
        break;
      case "jump":
        this.rig.jump();
        break;
      case "hit":
        this.damage(12, (Math.random() - 0.5) * Math.PI * 1.6);
        break;
      case "dieBack":
        this.health = 0;
        this.rig.die("back");
        break;
      case "dieFront":
        this.health = 0;
        this.rig.die("front");
        break;
      case "respawn":
        this.health = 100;
        this.rig.respawn(new THREE.Vector3(0, 0, 0));
        this.yaw = this.camYaw = 0;
        this.pitch = this.camPitch = 0.05;
        break;
      case "showcase":
        this.showcase = !this.showcase;
        if (!this.showcase) {
          this.camYaw = this.yaw;
          this.camPitch = this.pitch;
        } else {
          this.camPitch = 0.12;
        }
        break;
    }
    this.emitHud();
  }

  damage(n: number, angle: number) {
    if (this.rig.dead) return;
    this.health = Math.max(0, this.health - n);
    this.rig.hit(angle);
    this.shakeX.kick((Math.random() - 0.5) * 8);
    this.shakeY.kick(-5);
    if (this.health <= 0) this.rig.die(Math.abs(angle) < Math.PI / 2 ? "back" : "front");
  }

  /* ------------------------------------------------------------ */
  private onShot(muzzle: THREE.Vector3, kick: number) {
    const rig = this.rig;
    const dir = rig.aimPoint.clone().sub(muzzle).normalize();
    const moving = clamp(rig.speed / 4, 0, 1.2);
    const spread = (this.adsBlend > 0.5 ? 0.0018 : 0.009) + moving * 0.012 + (rig.grounded ? 0 : 0.02) + (this.crouchToggle ? -0.002 : 0);
    this.spread = spread;
    const r = () => (Math.random() - 0.5) * 2;
    dir.x += r() * spread;
    dir.y += r() * spread;
    dir.z += r() * spread;
    dir.normalize();
    this.raycaster.set(muzzle, dir);
    this.raycaster.far = 300;
    const hits = this.raycaster.intersectObjects(this.world.colliders, false);
    let end = muzzle.clone().addScaledVector(dir, 150);
    if (hits.length) {
      const h = hits[0];
      end = h.point.clone();
      const n = (h.face?.normal.clone() ?? new THREE.Vector3(0, 1, 0)).transformDirection(h.object.matrixWorld);
      const kind = (h.object.userData.kind as SurfaceKind) ?? "dirt";
      this.fx.impact(h.point, n, kind);
      if (kind === "metal") this.sfx.ping();
      if (h.object.userData.target) {
        this.world.hitTarget(h.object, 7);
        this.hitMarker = 0.18;
      }
    }
    this.fx.tracer(muzzle, end);
    this.fx.muzzleFlash(this.camera);
    this.sfx.shot();
    // camera recoil
    const k = kick;
    this.camKick.kick(1.3 * k);
    const dp = (0.0032 + Math.random() * 0.0022) * k;
    this.camPitch += dp;
    this.camYaw += (Math.random() - 0.5) * 0.0035 * k;
    if (!this.showcase) {
      this.pitch = this.camPitch;
      this.yaw = this.camYaw;
    }
    this.shakeX.kick(r() * 0.9 * k);
    this.shakeY.kick(r() * 0.9 * k);
  }

  /* ------------------------------------------------------------ */
  private frame(rawDt: number) {
    const rig = this.rig;
    const dt = rawDt * this.timeScale;
    const k = this.keys;
    const dead = rig.dead;

    // ---- input -> rig
    const f = (k.has("KeyW") || k.has("ArrowUp") ? 1 : 0) - (k.has("KeyS") || k.has("ArrowDown") ? 1 : 0);
    const s = (k.has("KeyD") || k.has("ArrowRight") ? 1 : 0) - (k.has("KeyA") || k.has("ArrowLeft") ? 1 : 0);
    const ay = this.showcase ? this.yaw : this.camYaw;
    const fwd = new THREE.Vector3(Math.sin(ay), 0, Math.cos(ay));
    const rgt = new THREE.Vector3(-Math.cos(ay), 0, Math.sin(ay));
    const mv = fwd.multiplyScalar(f).addScaledVector(rgt, s);
    if (mv.lengthSq() > 1) mv.normalize();
    rig.input.move.copy(mv);
    rig.input.sprint = k.has("ShiftLeft") || k.has("ShiftRight") || this.uiHeld.sprint;
    rig.input.crouch = this.crouchToggle || k.has("ControlLeft") || k.has("ControlRight");
    rig.input.ads = this.mouseR || this.uiHeld.ads || k.has("KeyZ");
    rig.input.lean = (k.has("KeyQ") ? 1 : 0) - (k.has("KeyE") ? 1 : 0);
    rig.aimYaw = this.yaw;
    rig.aimPitch = this.pitch;

    // ---- camera
    this.updateCamera(rawDt, dt);

    // ---- aim point from camera centre
    this.updateAimPoint();

    // ---- character
    rig.update(dt);

    // ---- firing
    const wantFire = (this.mouseL && (this.locked || this.lockFailed)) || k.has("KeyF") || this.uiHeld.fire;
    if (wantFire && !dead) {
      if (rig.mag <= 0 && rig.reserve > 0 && !rig.isReloading) {
        rig.fire(); // dry click
        if (rig.mag <= 0) setTimeout(() => this.rig?.reload(), 250);
      } else rig.fire();
    }

    this.spread = damp(this.spread, (this.adsBlend > 0.5 ? 0.002 : 0.01) + clamp(rig.speed / 4, 0, 1.2) * 0.012 + (rig.grounded ? 0 : 0.02), 8, rawDt);
    this.hitMarker = Math.max(0, this.hitMarker - rawDt);

    // ---- world / fx
    this.world.update(dt, rig.root.position);
    this.fx.update(dt);
    this.renderer.render(this.scene, this.camera);

    // ---- HUD
    this.fpsAcc += rawDt;
    this.fpsN++;
    this.hudT += rawDt;
    if (this.hudT > 0.1) {
      this.fps = this.fpsN / this.fpsAcc;
      this.fpsAcc = 0;
      this.fpsN = 0;
      this.hudT = 0;
      this.emitHud();
    }
  }

  private updateCamera(rawDt: number, dt: number) {
    const rig = this.rig;
    const cam = this.camera;
    const ads = rig.input.ads && !rig.dead;
    this.adsBlend = damp(this.adsBlend, ads ? 1 : 0, 12, rawDt);
    const sprinting = rig.status === "Sprinting";
    this.sprintFov = damp(this.sprintFov, sprinting ? 7 : 0, 5, rawDt);
    cam.fov = lerp(62, 46, this.adsBlend) + this.sprintFov;
    cam.updateProjectionMatrix();

    const kick = this.camKick.update(0, dt);
    const sx = this.shakeX.update(0, dt);
    const sy = this.shakeY.update(0, dt);

    const targetPivot = rig.dead ? 0.7 : rig.eyeHeight;
    this.pivotY = damp(this.pivotY, targetPivot, 10, rawDt);
    const root = rig.root.position;
    const pivot = new THREE.Vector3(root.x, root.y + this.pivotY, root.z);

    let yaw = this.camYaw;
    let pitch = this.camPitch;
    let dist = this.zoomDist;
    let shoulder = 0.55;
    if (this.showcase) {
      if (!this.mouseL && !this.mouseR) this.camYaw += rawDt * 0.35;
      yaw = this.camYaw;
      pitch = this.camPitch;
      dist = this.zoomDist;
      shoulder = 0;
      pivot.y = root.y + 1.05;
    } else {
      dist = lerp(this.zoomDist, 1.45, this.adsBlend);
      shoulder = lerp(0.55, 0.36, this.adsBlend);
    }
    const p = pitch + kick * 0.01;
    const fwd = new THREE.Vector3(Math.sin(yaw) * Math.cos(p), Math.sin(p), Math.cos(yaw) * Math.cos(p));
    const right = new THREE.Vector3(-Math.cos(yaw), 0, Math.sin(yaw));
    const desired = pivot.clone().addScaledVector(fwd, -dist).addScaledVector(right, shoulder);
    desired.y += this.showcase ? 0 : 0.12;

    // camera collision
    const toCam = desired.clone().sub(pivot);
    const len = toCam.length();
    this.raycaster.set(pivot, toCam.clone().normalize());
    this.raycaster.far = len;
    const hits = this.raycaster.intersectObjects(this.world.colliders, false);
    if (hits.length && hits[0].distance < len) desired.copy(pivot).addScaledVector(toCam.normalize(), Math.max(0.35, hits[0].distance - 0.2));
    if (desired.y < 0.15) desired.y = 0.15;

    cam.position.copy(desired);
    cam.rotation.order = "YXZ";
    cam.rotation.y = yaw + Math.PI + sx * 0.0008;
    cam.rotation.x = p + sy * 0.0008;
    cam.rotation.z = rig.input.lean * -0.04;
    cam.updateMatrixWorld(true);
  }

  private updateAimPoint() {
    const rig = this.rig;
    if (this.showcase) {
      rig.aimPoint.set(rig.root.position.x + Math.sin(this.yaw) * 40, 1.4 + Math.tan(this.pitch) * 40, rig.root.position.z + Math.cos(this.yaw) * 40);
      return;
    }
    const origin = this.camera.position;
    const dir = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
    this.raycaster.set(origin, dir);
    this.raycaster.far = 200;
    // skip anything closer than the character
    const hits = this.raycaster.intersectObjects(this.world.colliders, false);
    const minD = origin.distanceTo(rig.root.position.clone().setY(1.2)) + 0.6;
    const h = hits.find((x) => x.distance > minD);
    if (h) rig.aimPoint.copy(h.point);
    else rig.aimPoint.copy(origin).addScaledVector(dir, 120);
  }

  /* ------------------------------------------------------------ */
  private emitHud() {
    const r = this.rig;
    this.onHud({
      loading: this.loading,
      progress: this.progress,
      ammo: r?.mag ?? MAG_SIZE,
      reserve: r?.reserve ?? 120,
      health: this.health,
      status: r?.status ?? "Idle",
      speed: r?.speed ?? 0,
      reloading: r?.isReloading ?? false,
      reloadProgress: r?.reloadProgress ?? 0,
      locked: this.locked,
      dead: r?.dead ?? false,
      crouch: this.crouchToggle,
      ads: this.uiHeld.ads,
      sprint: this.uiHeld.sprint,
      showcase: this.showcase,
      fps: this.fps,
      spread: this.spread,
      hitMarker: this.hitMarker,
      timeScale: this.timeScale,
    });
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.cleanup.forEach((c) => c());
    this.ro?.disconnect();
    if (document.pointerLockElement) document.exitPointerLock();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}
